import styled from '@emotion/styled';
import Drawer from '@mui/material/Drawer';
import Typography from '@mui/material/Typography';
import AppBar from '@mui/material/AppBar';
import Avatar from '@mui/material/Avatar';
import Card from '@mui/material/Card';
import { blue, green, pink, yellow } from '@mui/material/colors';
import { IconButton, Link } from '@mui/material';

const drawerWidth = 260;
const rightDrawerWidth = 280;

export const StyledCard = styled(Card)(({theme, note}) => ({
    border: `${
        note.noteCategory === 'work' ? '2px solid ' + yellow[700] : 
        note.noteCategory === 'reminders' ? '2px solid ' + blue[500] :
        note.noteCategory === 'todos' ? '2px solid ' + pink[500] :
        '2px solid ' + green[500]
    }`
}));

export const StyledDrawer = styled(Drawer)(({ theme }) => ({
  width: drawerWidth,
  '& .MuiDrawer-paper': {
    width: drawerWidth,
  },
}));

export const StyledRightDrawer = styled(Drawer)(({ theme }) => ({
  width: rightDrawerWidth,
  '& .MuiDrawer-paper': {
    width: rightDrawerWidth,
  },
}));

export const StyledDivRoot = styled('div')(({ theme }) => ({
  display: 'flex',
}));

export const StyledDivPage = styled('div')(({ theme }) => ({
  width: '100%',
  padding: theme.spacing(3),
}));

export const StyledIconButton = styled(IconButton)(({ theme }) => ({
  marginRight: theme.spacing(2)
}));

export const StyledDivToolbar = styled('div')(({ theme }) => ({
  ...theme.mixins.toolbar,
}));

export const StyledTypographyTitle = styled(Typography)(({ theme }) => ({
  padding: theme.spacing(2),
  flexGrow: 1
}));

export const StyledTypographyDate = styled(Typography)(({ theme }) => ({
    flexGrow: 1
  }));

export const StyledAppBar = styled(AppBar)(({ theme }) => ({
  /* width: `calc(100% - ${drawerWidth}px)`, */
  backdropFilter: 'blur(10px)',
}));

export const StyledAvatar = styled(Avatar)(({ theme }) => ({
    marginLeft: theme.spacing(2)
}));

export const StyledNoteCardAvatar = styled(Avatar)(({ theme, note }) => ({
    backgroundColor: `${ 
        note.noteCategory === 'work' ? yellow[700] : 
        note.noteCategory === 'money' ? green[500] :
        note.noteCategory === 'todos' ? pink[500] : 
        blue[500] 
    }`
}));

export const StyledIconButtonFavorite = styled(IconButton)(({ theme }) => ({
    fontSize: 'small',
    '&hover': {
        color: 'primary',
        transition: 'color 0.3s ease-in-out', 
    }
}));

export const StyledProductLink = styled(Link)(({ theme }) => ({
    textDecoration: 'none',
    
}));

export const classes = {
  active: {
    background: '#424242',
  },
};
