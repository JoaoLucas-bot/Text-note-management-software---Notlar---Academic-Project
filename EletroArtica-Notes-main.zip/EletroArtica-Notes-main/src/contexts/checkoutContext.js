import React from 'react';

const CheckoutContext = React.createContext();

export default CheckoutContext;