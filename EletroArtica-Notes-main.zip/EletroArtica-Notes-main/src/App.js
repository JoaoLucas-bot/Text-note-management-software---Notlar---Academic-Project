import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Products from './pages/Products';
import Create from './pages/Create';
import Login from './pages/Login';
import { createTheme, CssBaseline, ThemeProvider } from '@mui/material';
import Layout from './components/Layout';
import Home from './pages/Home';
import UserContext from './contexts/userContext';
import CheckoutContext from './contexts/checkoutContext';
import { useState } from 'react';
import Logout from './pages/Logout';
import SignUp from './pages/Signup';
import Checkout from './pages/Checkout';
import AddressForm from './pages/AddressForm';
import PaymentForm from './pages/PaymentForm';
import Review from './pages/Review';
import UserProfile from './pages/UserProfile';
import Note from './pages/Note';
import SharedNote from './pages/SharedNote';

const theme = createTheme({
  typography: {
    fontFamily: 'Quicksand',
    fontWeightLight: 400,
    fontWeightRegular: 500,
    fontWeightMedium: 600,
    fontWeightBild: 700,
  }
});

const darkTheme = createTheme({
  palette: {
    mode: 'dark'
  },
  typography: {
    fontFamily: 'Quicksand',
    fontWeightLight: 400,
    fontWeightRegular: 500,
    fontWeightMedium: 600,
    fontWeightBold: 700,
  },
});

function App() {
  const [user, setUser] = useState(() => {
    console.log('App.js - ' + localStorage.getItem('user'));
    if (localStorage.getItem('user')) {
      console.log('App.js - UserContext populated with localStorage data');
      return JSON.parse(localStorage.getItem('user'));
    }
    console.log('App.js - UserContext NOT populated with localStorage data');
    return null;
  });
  const [checkoutForm, setCheckoutForm] = useState(() => {
    return {
      firstName: '',
      lastName: '',
      address1: '',
      zip: '',
      country: '',
      cardNumber: '',
      expDate: '',
      cvv: '',
      cardType: '',
      total: 0,
      cart: []
    }
  });

  return (
    <ThemeProvider theme={darkTheme}>
      <CssBaseline />
      <UserContext.Provider value={{ user, setUser }}>
        <CheckoutContext.Provider value={{ checkoutForm, setCheckoutForm}}>
          <Router>
            <Layout>
              <Routes>
                <Route exact path="/" element={<Home />}>   
                </Route>
                <Route exact path="/products" element={<Products />}>   
                </Route>
                <Route path="/create" element={<Create />}>
                </Route>
                <Route path="/login" element={<Login />}>
                </Route>
                <Route path="/logout" element={<Logout />}>
                </Route>
                <Route path="/signup" element={<SignUp />}>
                </Route>
                <Route path="/checkout" element={<Checkout />}>
                </Route>
                <Route path="/AddressForm" element={<AddressForm />}>
                </Route>
                <Route path="/PaymentForm" element={<PaymentForm />}>
                </Route>
                <Route path="/Review" element={<Review />}>
                </Route>
                <Route path="/profile" element={<UserProfile />}>
                </Route>
                <Route path="/note/:id" element={<Note />}>
                </Route>
                <Route path="/note/shared/:id" element={<SharedNote />}>
                </Route>
              </Routes>
            </Layout>
          </Router>
        </CheckoutContext.Provider>
      </UserContext.Provider>
    </ThemeProvider>
  );
}

export default App;
