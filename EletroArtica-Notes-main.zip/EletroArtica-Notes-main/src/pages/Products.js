import React, { useEffect, useState } from 'react'
import Container from '@mui/material/Container';
import ProductCard from '../components/ProductCard';
import Masonry from 'react-masonry-css';
import { Typography } from '@mui/material';

export default function Products() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('https://api.eletroartica.net/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data)
      })
  }, []);

  const breakpointColumnsObj = {
    default: 4,
    1150: 3,
    970: 2,
    750: 1
  };

  return (
    <Container>
      <Typography gutterBottom variant='h3'>
          All Products
      </Typography>
      <Masonry
        breakpointCols={breakpointColumnsObj}
        className="my-masonry-grid"
        columnClassName="my-masonry-grid_column"
      >
        {products.map(product => (
          <div key={ product.productId }>
            <ProductCard product={product} />
          </div>
        ))}
      </Masonry>
    </Container>
  )
}
