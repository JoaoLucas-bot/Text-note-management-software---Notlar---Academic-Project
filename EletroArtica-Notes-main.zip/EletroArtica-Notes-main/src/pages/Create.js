import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import KeyboardArrowRightIcon from '@mui/icons-material/KeyboardArrowRight';
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import { useNavigate } from 'react-router-dom'

const classes = {
  field: {
    marginTop: 2,
    marginBottom: 2,
    display: 'block',
  }
};

export default function Create() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [titleError, setTitleError] = useState(false);
  const [contentError, setContentError] = useState(false);
  const [category, setCategory] = useState('work');
  const navigate = useNavigate(); 

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
      navigate('/login');
    }
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault()
    setTitleError(false);
    setContentError(false);

    if(title === ''){
      setTitleError(true);
    }
    if(content === ''){
      setContentError(true);
    }
    if(title && content){
      fetch('https://api.eletroartica.net/api/notes/create', {
        method: 'POST',
        credentials: 'include',
        withCredentials: true,
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ title, content, category})
      }).then(() => navigate('/'));
    }
  };

  return (
    <Container component="main" maxWidth="sm">
      <Typography
        variant='h6'
        component="h2"
        color="textSecondary"
        gutterBottom
      >
        Create a New Note
      </Typography>

      <form noValidate autoComplete='off' onSubmit={handleSubmit}>
        <TextField
          onChange={(e) => {setTitle(e.target.value)}}
          sx={classes.field}
          label="Note title" 
          fullWidth
          required
          error={titleError}
        >
        </TextField>
        <TextField
          onChange={(e) => {setContent(e.target.value)}}
          sx={classes.field}
          label="Note Content"
          multiline
          rows={4}
          fullWidth
          required
          error={contentError}
        >
        </TextField>

        <FormControl sx={classes.field}>
          <FormLabel>Note Category</FormLabel>
          <RadioGroup value={category} onChange={(e) => setCategory(e.target.value)} >
            <FormControlLabel value='work' control={<Radio />} label='Work' />
            <FormControlLabel value='reminders' control={<Radio />} label='Reminders' />
            <FormControlLabel value='todos' control={<Radio />} label='ToDos' />
            <FormControlLabel value='money' control={<Radio />} label='Money' />
          </RadioGroup>
        </FormControl>

        <Button
          type='submit'
          variant='contained'
          endIcon={<KeyboardArrowRightIcon />}
        >
          Submit
        </Button><br />
      </form>
    </Container>
  )
}
