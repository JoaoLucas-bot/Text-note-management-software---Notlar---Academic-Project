import React, { useContext, useEffect, useState } from 'react'
import Container from '@mui/material/Container';
import Masonry from 'react-masonry-css';
import { CssBaseline, Typography } from '@mui/material';
import NoteCard from '../components/NoteCard';
import SharedNoteCard from '../components/SharedNoteCard';
import UserContext from '../contexts/userContext';

export default function Products() {
  const [myNotes, setMyNotes] = useState([]);
  const [sharedNotes, setSharedNotes] = useState([]);
  const { user } = useContext(UserContext);
  
  useEffect(() => {
    fetch('https://api.eletroartica.net/api/notes/', {
      method: 'GET',
      credentials: 'include',
      withCredentials: true,
    })
      .then(res => res.json())
      .then(notes => {
        console.log('Notes: ', notes);
        setMyNotes(notes)
        console.log('myNotes: ', myNotes);
        console.log('myNotes: ', myNotes.length);
      })
    fetch('https://api.eletroartica.net/api/notes/shared', {
      method: 'GET',
      credentials: 'include',
      withCredentials: true,
    })
      .then(res => res.json())
      .then(shared => {
        setSharedNotes(shared)
        console.log('sharedNotes', sharedNotes);
      })
  }, []);

  const handleDelete = async (noteId) => {
    await fetch(`https://api.eletroartica.net/api/notes/note/${noteId}`, {
        method: 'DELETE',
        credentials: 'include',
        withCredentials: true,
    })
    .then(setMyNotes(myNotes.filter(note => note.noteId !== noteId)));
}

  const breakpointColumnsObj = {
    default: 4,
    1150: 3,
    970: 2,
    750: 1
  };

  return (
    <div>
      { user ? (
        <Container component="main">
          <CssBaseline/>
          <Typography gutterBottom variant='h3'>
              My Notes
          </Typography>
          {myNotes.length > 0 &&
            <Masonry
                breakpointCols={breakpointColumnsObj}
                className="my-masonry-grid"
                columnClassName="my-masonry-grid_column"
            >
                {myNotes.map(note => (
                    <div key={ note.noteId }>
                    <NoteCard note={note} handleDelete={handleDelete}/>
                    </div>
                ))}
            </Masonry>
          }
          <Typography gutterBottom variant='h3'>
              Shared with Me
          </Typography>
          {sharedNotes.length > 0 &&
            <Masonry
                breakpointCols={breakpointColumnsObj}
                className="my-masonry-grid"
                columnClassName="my-masonry-grid_column"
            >
                {sharedNotes.map(note => (
                    <div key={ note.noteId }>
                      <SharedNoteCard note={note} />
                    </div>
                ))}
            </Masonry>
          }
          
        </Container>
      ) : (<Typography variant='h5'>Welcome to EletroArtica - NOTLAR! <br/><br /> Please Login to see your notes</Typography>)}
    </div>
  )
}