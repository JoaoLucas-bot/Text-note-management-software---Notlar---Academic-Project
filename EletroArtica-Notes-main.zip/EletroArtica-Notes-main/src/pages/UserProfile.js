import React, { useState, useContext, useEffect } from 'react';
import { TextField, Button, Box, Typography, Avatar, Container, CssBaseline, Grid } from '@mui/material';
import UserContext from '../contexts/userContext';

const setLocalStorage = (setUser) => {
  
  fetch('https://api.eletroartica.net/api/user/userBasicInfo', {
    method: "GET",
    credentials: 'include',
    withCredentials: true,
  })
  .then((res) => res.json())
  .then((loginData) => {
    console.log('Login.js - userBasicInfo: ' + loginData);
    const user = {
      firstName: loginData.firstName,
      lastName: loginData.lastName,
      icon: loginData.icon,
      favorites: loginData.favorites,
      cart: loginData.cart,
      loggedIn: true
    };
    console.log('Your favorites: ', user.favorites);
    console.log('Your cart: ', user.cart);
    localStorage.setItem('user', JSON.stringify(user));
    setUser(JSON.parse(localStorage.getItem('user')));
  })
};

const UserProfile = () => {
  const [email, setEmail] = useState('');
  const [userIcon, setUserIcon] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [address, setAddress] = useState('null');
  const [nif, setNif] = useState('null');
  const { user, setUser } = useContext(UserContext);

  async function fetchData() {
    await fetch(`https://api.eletroartica.net/api/user/profile`, {
      method: 'GET',
      credentials: 'include',
      withCredentials: true,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      }
    })
    .then((res) => res.json())
    .then((data) => {
      console.log('UserProfile.js - data:', data);
      setEmail(data.email);
      setUserIcon(data.userIcon);
      setFirstName(data.firstName);
      setLastName(data.lastName);
      setAddress(data.address);
      setNif(data.nif);
    })
  }

  const handleSave = (event) => {
    event.preventDefault();
    const formData = new FormData();
    if (userIcon === '') formData.append('userIcon', user.icon);
    else formData.append('userIcon', userIcon);
    formData.append('firstName', firstName);
    formData.append('lastName', lastName);
    if (address === '' || address === "null") formData.append('address', 'null');
    else formData.append('address', address);
    if (nif === '' || nif === "null") formData.append('nif', 'null');
    else formData.append('nif', nif);
    formData.append('email', email);

    console.log('UserProfile.js - formData:', ...formData);

    fetch(`https://api.eletroartica.net/api/user/profile`, {
      method: 'PUT',
      credentials: 'include',
      withCredentials: true,
      body: formData
    })
    .then((res) => {
      if (res.ok) {
        console.log('Profile information saved!');
        setLocalStorage(setUser);
        fetchData();
      } else { console.log('Profile information NOT saved!') }
    })
    console.log('Profile information saved:', { email, userIcon, firstName, lastName, address, nif });
  };

  const handleIconChange = (event) => {
    setUserIcon(event.target.files[0]);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <Container>
      <CssBaseline/>
      <Typography variant="h4" component="h1" gutterBottom>
        User Profile
      </Typography>
      <Box component="form" noValidate autoComplete='off'>
        {email !== '' &&
        <Grid container marginTop={6} flex={1} alignItems="center" sx={{flexDirection: 'column'}}>
          <Grid item xs={12} sm={2}>
            <Avatar src={`https://api.eletroartica.net/storage/userPics/${user.icon}`} sx={{ m: 1, bgcolor: 'secondary.main', width: 100, height: 100 }} />
            <Button variant="contained" component="label">
              Upload File
              <input type="file" hidden onChange={handleIconChange} />
            </Button>
          </Grid>
          <Grid item xs={12} sm={6}>
            <Grid container spacing={2} marginTop={1}>
              <Grid item xs={12} sm={6}>
                <TextField
                  defaultValue={firstName}
                  name="firstName"
                  required
                  fullWidth
                  id="firstName"
                  label="First Name"
                  onChange={(e) => setFirstName(e.target.value)}
                />
              </Grid>
              <Grid item xs={12} sm={6}>
                <TextField
                  defaultValue={lastName}
                  required
                  fullWidth
                  id="lastName"
                  label="Last Name"
                  name="lastName"
                  onChange={(e) => setLastName(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  defaultValue={email}
                  inputProps={{ readOnly: true }}
                  fullWidth
                  id="email"
                  label="Email Address"
                  name="email"
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  defaultValue={address}
                  fullWidth
                  name="address"
                  label="Address"
                  id="address"
                  onChange={(e) => setAddress(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  defaultValue={nif}
                  required
                  fullWidth
                  name="nif"
                  label="NIF"
                  id="nif"
                  onChange={(e) => setNif(e.target.value)}
                />
              </Grid>
            </Grid>
            <Button
              type="submit"
              fullWidth
              variant="contained"
              sx={{ mt: 3, mb: 2 }}
              onClick={handleSave}
            >
              Save
            </Button>
          </Grid>
        </Grid>
        }
      </Box>
    </Container>
  );
};

export default UserProfile;
