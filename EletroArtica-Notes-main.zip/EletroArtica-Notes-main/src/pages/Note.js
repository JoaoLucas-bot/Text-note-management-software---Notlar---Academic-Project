import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import SaveIcon from '@mui/icons-material/Save';
import ShareIcon from '@mui/icons-material/Share';
import { useNavigate, useParams } from 'react-router-dom'
import { Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Grid } from '@mui/material';

const classes = {
  field: {
    marginTop: 2,
    marginBottom: 2,
    display: 'block',
  }
};

export default function Note() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [titleError, setTitleError] = useState(false);
  const [contentError, setContentError] = useState(false);
  const navigate = useNavigate();
  const noteId = useParams().id;
  const [open, setOpen] = React.useState(false);

  const fetchNote = async () => {
    const user = JSON.parse(localStorage.getItem('user'));
    console.log(noteId);
    if (!user) {
      navigate('/login');
    } else {
      await fetch('https://api.eletroartica.net/api/notes/note/' + noteId, {
        method: 'GET',
        credentials: 'include',
        withCredentials: true,
      })
      .then(res => res.json())
      .then(note => {
        console.log('Note: ', note);
        console.log('Note Title: ', note[0].noteTitle);
        console.log('Note Content: ', note[0].noteContent);
        console.log('Note Category: ', note[0].noteCategory);
        setTitle(note[0].noteTitle);
        setContent(note[0].noteContent);
        setCategory(note[0].noteCategory);
      })
    }
  };

  useEffect(() => {
    fetchNote();

  }, []);

  const handleClickOpen = () => {
    setOpen(true);
  }

  const handleClose = () => {
    setOpen(false);
  }

  const handleShare = (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const formJson = Object.fromEntries(formData.entries());
    const email = formJson.email;
    console.log(email);
    fetch('https://api.eletroartica.net/api/notes/share/' + noteId, {
      method: 'POST',
      credentials: 'include',
      withCredentials: true,
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ email })
    }).then(data => {
      console.log(data);
    });
    handleClose();
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setTitleError(false);
    setContentError(false);

    if(title === ''){
      setTitleError(true);
    }
    if(content === ''){
      setContentError(true);
    }
    if(title && content){
      fetch('https://api.eletroartica.net/api/notes/note/' + noteId, {
        method: 'PUT',
        credentials: 'include',
        withCredentials: true,
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ title, content, category})
      }).then(data => {
        console.log(data);
      });
    }
  };

  return (
    <div>
      { category && 
        <Container component="main" maxWidth="sm">
          <Typography
            variant='h3'
            component="h2"
            gutterBottom
          >
            Edit your note             
          </Typography>

          <form noValidate autoComplete='off' onSubmit={handleSubmit}>
            <TextField
              onChange={(e) => {setTitle(e.target.value)}}
              sx={classes.field}
              label="Note title" 
              fullWidth
              required
              defaultValue={title}
              error={titleError}
            >
            </TextField>
            <TextField
              onChange={(e) => {setContent(e.target.value)}}
              sx={classes.field}
              label="Note Content"
              multiline
              rows={4}
              fullWidth
              required
              defaultValue={content}
              error={contentError}
            >
            </TextField>
            <FormControl sx={classes.field}>
              <FormLabel>Note Category</FormLabel>
              <RadioGroup value={category} onChange={(e) => setCategory(e.target.value)} >
                <FormControlLabel value='work' control={<Radio />} label='Work' />
                <FormControlLabel value='reminders' control={<Radio />} label='Reminders' />
                <FormControlLabel value='todos' control={<Radio />} label='ToDos' />
                <FormControlLabel value='money' control={<Radio />} label='Money' />
              </RadioGroup>
            </FormControl>
            <Grid container columns={2} columnGap={1}>
              <Button
                type='submit'
                variant='contained'
                startIcon={<SaveIcon />}
              >
                Save
              </Button><br />

              <Button variant='contained' startIcon={<ShareIcon />} onClick={handleClickOpen}>
                Share Note
              </Button>
            </Grid>
          </form>
          
          <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event) => {handleShare(event)},
        }}
      >
        <DialogTitle>Share Note</DialogTitle>
        <DialogContent>
          <DialogContentText>
            To share your note, please enter the email address of the person you want to share it with.
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="name"
            name="email"
            label="Email Address"
            type="email"
            fullWidth
            variant="standard"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button type="submit" >Share</Button>
        </DialogActions>
      </Dialog>
          
        </Container>
      }
    </div>
  )
}
