import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button'
import Container from '@mui/material/Container'
import Typography from '@mui/material/Typography'
import TextField from '@mui/material/TextField';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import FormLabel from '@mui/material/FormLabel';
import SaveIcon from '@mui/icons-material/Save';
import { useNavigate, useParams } from 'react-router-dom'

const classes = {
  field: {
    marginTop: 2,
    marginBottom: 2,
    display: 'block',
  }
};

export default function SharedNote() {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState('');
  const [titleError, setTitleError] = useState(false);
  const [contentError, setContentError] = useState(false);
  const navigate = useNavigate();
  const noteId = useParams().id;

  const fetchNote = async () => {
    const user = JSON.parse(localStorage.getItem('user'));
    console.log(noteId);
    if (!user) {
      navigate('/login');
    } else {
      await fetch('https://api.eletroartica.net/api/notes/shared/' + noteId, {
        method: 'GET',
        credentials: 'include',
        withCredentials: true,
      })
      .then(res => res.json())
      .then(note => {
        console.log('Note: ', note);
        console.log('Note Title: ', note[0].noteTitle);
        console.log('Note Content: ', note[0].noteContent);
        console.log('Note Category: ', note[0].noteCategory);
        setTitle(note[0].noteTitle);
        setContent(note[0].noteContent);
        setCategory(note[0].noteCategory);
      })
    }
  };

  useEffect(() => {
    fetchNote();
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault()
    setTitleError(false);
    setContentError(false);

    if(title === ''){
      setTitleError(true);
    }
    if(content === ''){
      setContentError(true);
    }
    if(title && content){
      fetch('https://api.eletroartica.net/api/notes/shared/' + noteId, {
        method: 'PUT',
        credentials: 'include',
        withCredentials: true,
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ title, content, category})
      }).then(data => {
        console.log(data);
      });
    }
  };

  return (
    <div>
      { category &&
        <Container component="main" maxWidth="sm">
          <Typography
            variant='h3'
            component="h2"
            gutterBottom
          >
            Edit Shared Note             
          </Typography>

          <form noValidate autoComplete='off' onSubmit={handleSubmit}>
            <TextField
              onChange={(e) => {setTitle(e.target.value)}}
              sx={classes.field}
              label="Note title" 
              fullWidth
              required
              defaultValue={title}
              error={titleError}
            >
            </TextField>
            <TextField
              onChange={(e) => {setContent(e.target.value)}}
              sx={classes.field}
              label="Note Content"
              multiline
              rows={4}
              fullWidth
              required
              defaultValue={content}
              error={contentError}
            >
            </TextField>

            <FormControl sx={classes.field}>
              <FormLabel>Note Category</FormLabel>
              <RadioGroup value={category} onChange={(e) => setCategory(e.target.value)} >
                <FormControlLabel value='work' control={<Radio />} label='Work' />
                <FormControlLabel value='reminders' control={<Radio />} label='Reminders' />
                <FormControlLabel value='todos' control={<Radio />} label='ToDos' />
                <FormControlLabel value='money' control={<Radio />} label='Money' />
              </RadioGroup>
            </FormControl>

            <Button
              type='submit'
              variant='contained'
              startIcon={<SaveIcon />}
            >
              Save
            </Button><br />
          </form>
        </Container>
      }
    </div>
  )
}
