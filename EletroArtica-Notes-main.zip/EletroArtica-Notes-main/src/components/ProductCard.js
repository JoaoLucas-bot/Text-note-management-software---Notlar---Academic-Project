import React, { useContext, useState, forwardRef } from 'react';
import { Card, CardActionArea, CardContent, CardMedia, Typography, Button, IconButton, Divider, Link, Snackbar } from '@mui/material';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import StarIcon from '@mui/icons-material/Star';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import { green, red } from '@mui/material/colors';
import { StyledIconButtonFavorite, StyledProductLink } from '../styles/Styles';
import CancelRoundedIcon from '@mui/icons-material/CancelRounded';
import UserContext from '../contexts/userContext';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import MuiAlert from '@mui/material/Alert';
import { useNavigate } from 'react-router-dom';


const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} {...props} />;
  });

export default function ProductCard({ product }) {
    const { user, setUser } = useContext(UserContext);
    const [ openCartAlert, setOpenCartAlert ] = useState(false);
    const [ openFavoriteAlert, setOpenFavoriteAlert ] = useState(false);
    const [ success, setSuccess ] = useState(false);
    const navigate = useNavigate();

    const handleAlertClose = (event, reason) => {
        if (reason === 'clickaway') {
          return;
        }
        setOpenCartAlert(false);
        setOpenFavoriteAlert(false);
    };

    const handleFavoriteClick = ({ product }) => {
        console.log('Item favorited: '+ product.productId);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        

        if (user !== null) {
            console.log('Current user data: ', user);
            console.log('Current favorites: ' + user.favorites)
            fetch('https://api.eletroartica.net/api/user/favorites/', {
                method: 'POST',
                headers: headers,
                credentials: 'include',
                withCredentials: true,
                body: JSON.stringify({ favorite: product.productId })
            })
            .then(res => res.json())
            .then(data => {
                console.log('ProductCard.js - Received data: ' + {data});
                if (data.result === 'Favorite already exists!') {
                    console.log('Favorite already exists!');
                    setSuccess(false);
                    setOpenFavoriteAlert(true);
                } else if (data.result === 'Error adding favorite!') {
                    console.log('Error adding favorite!');
                } else {
                    const newUserData = JSON.parse(localStorage.getItem('user'));
                    console.log('ProductCard.js - New user data (before favorite): ', newUserData);
                    console.log('ProductCard.js - New user Favorites (before favorite): ', newUserData.favorites);
                    newUserData.favorites.push(product);
                    console.log('ProductCard.js - New user data (after favorite): ', newUserData);
                    localStorage.setItem('user', JSON.stringify(newUserData));
                    setUser( newUserData );
                    
                    console.log('ProductCard.js - Favorite added successfully!');
                    setSuccess(true);
                    setOpenFavoriteAlert(true);
                }
            })
        } else {
            navigate('/login');
        }
        
        /* if(!localStorage.getItem('favorite')){
          localStorage.setItem('favorite', [id]);
          console.log('Current favorites: ' + localStorage.getItem('favorite'));
          return;
        } else if(localStorage.getItem('favorite').includes(id)){
          console.log('Item already favorited!');
          return;
        } else {
          let favorites = localStorage.getItem('favorite');
          favorites = favorites.split(',');
          favorites.push(id);
          localStorage.setItem('favorite', favorites);
          console.log('Current favorites: ' + localStorage.getItem('favorite'));
          return;
        } */
    }

    const handleCartClick = ({ product }) => {
        console.log('Item being added to cart: '+ product.productId);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');

        if (user !== null) {
            if (product.productStock === 0) {
                console.log('Product out of stock!');
                setSuccess(false);
                setOpenCartAlert(true);
                return;
            }
            console.log('Current user data: ', user);
            console.log('Current cart: ' + user.cart)
            fetch('https://api.eletroartica.net/api/shopping/cart/item', {
                method: 'POST',
                headers: headers,
                credentials: 'include',
                withCredentials: true,
                body: JSON.stringify({ productId: product.productId, quantity: 1 })
            })
            .then(res => {
                console.log('ProductCard.js - Received data: ' + res.ok);
                if (!res.ok) {
                    console.log('Error adding item to cart!');
                    setSuccess(false);
                    setOpenCartAlert(true);
                } else {
                    fetch('https://api.eletroartica.net/api/shopping/cart', {
                        method: "GET",
                        credentials: 'include',
                        withCredentials: true,
                    })
                    .then((res) => res.json())
                    .then((cartData) => {
                        const localStorageUser = JSON.parse(localStorage.getItem('user'));
                        console.log('CartDrawerItem.js - User data (before cart item removal): ', user);
                        console.log('CartDrawerItem.js - User cart (before item removal): ', localStorageUser.cart);
                        localStorageUser.cart = cartData;
                        console.log('CartDrawerItem.js - New user cart (after item removal): ', localStorageUser);
                        localStorage.setItem('user', JSON.stringify(localStorageUser));
                        setUser( localStorageUser );
                        console.log('ProductCard.js - Shopping cart item added successfully!');
                        setSuccess(true);
                        setOpenCartAlert(true);
                    })
                }
            })
        } else {
            navigate('/login');
        }
    }

    return (
        <Card>
            <Link href={`/product/${product.productId}`}>       
                <CardMedia
                    component="img"
                    alt="Product Image"
                    height="200"
                    image={`https://api.eletroartica.net/storage/productPics/${product.productPhoto}`}
                    title={product.productName}
                />
            </Link>
            <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                    <Link href={`/product/${product.productId}`} underline='hover'>
                        {product.productName.length > 30 ? `${product.productName.substring(0, 30)}...` : product.productName}
                    </Link>
                </Typography>
                <Typography variant="body2" color="textSecondary" component="div" gutterBottom>
                    {product.productDescription}
                </Typography>
                {product.productStock > 0 ? (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <CheckCircleRoundedIcon color='success'/>
                        <Typography variant="body2" color={green[300]} component="div" flexGrow={1}>
                            In Stock
                        </Typography>
                        <Typography variant="h6" color="textSecondary" component="div" style={{ marginLeft: '10px' }}>
                            €{product.productPrice}
                        </Typography>
                    </div>
                ) : (
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                        <CancelRoundedIcon color='error'/>
                        <Typography variant="body2" color={red[300]} component="div" flexGrow={1}>
                            Out of Stock
                        </Typography>
                        <Typography variant="h6" color="textSecondary" component="div" style={{ marginLeft: '10px' }}>
                            €{product.productPrice}
                        </Typography>
                    </div>
                )}
                <Divider style={{ margin: '10px 0' }} />
                <div style={{ display: 'flex', alignItems: 'center' }}>
                    <StyledIconButtonFavorite
                        onClick={() => handleFavoriteClick({product}) }
                        aria-label="Add to favorites"
                        disableFocusRipple
                        disableRipple
                        color='primary'
                        edge='start'
                        sx={{
                            '&:hover': {
                                color: 'primary.dark',
                                transition: 'color 0.3s ease-in-out', // Add transition property
                            },
                        }}
                    >
                        <StarIcon /> Add to favorites
                    </StyledIconButtonFavorite>
                    <Snackbar open={openFavoriteAlert} autoHideDuration={6000} onClose={handleAlertClose}>
                        <Alert onClose={handleAlertClose} severity={success ? "success" : "warning"} sx={{ width: '100%' }}>
                            {success ? "Item added to favorites!" : "Item already favorited!"}
                        </Alert>
                    </Snackbar>
                    <StyledIconButtonFavorite
                        onClick={() => handleCartClick({product}) }
                        aria-label="Add to cart"
                        disableFocusRipple
                        disableRipple
                        color='primary'
                        sx={{
                            '&:hover': {
                                color: 'primary.dark',
                                transition: 'color 0.3s ease-in-out', // Add transition property
                            },
                        }}
                    >
                        <ShoppingCartIcon /> Add to cart
                    </StyledIconButtonFavorite>
                    <Snackbar open={openCartAlert} autoHideDuration={6000} onClose={handleAlertClose}>
                        <Alert onClose={handleAlertClose} severity={success ? "success" : "error"} sx={{ width: '100%' }}>
                            {success ? "Item added to cart!" : "Error adding item to cart!"}
                        </Alert>
                    </Snackbar>

                </div>
            </CardContent>       
        </Card>
    );
};
