import { IconButton, ListItem, ListItemIcon, ListItemText, Typography } from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';
import { useContext } from "react";
import UserContext from "../contexts/userContext";
import Link from '@mui/material/Link';


const FavoriteItem = ({product}) => {
    const navigate = useNavigate();
    console.log('Product in list: ' + {product});
    const { user, setUser } = useContext(UserContext);

    const handleDeleteClick = (productId) => {
        console.log('Favorite being removed: '+ productId);
        console.log('Current favorites: ' + user.favorites)
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        console.log('Current user data: ', user);
    
        if (user !== null) {
            fetch('https://api.eletroartica.net/api/user/favorites/', {
                method: 'DELETE',
                headers: headers,
                credentials: 'include',
                withCredentials: true,
                body: JSON.stringify({ favorite: productId })
            })
            .then(res => res.json())
            .then(data => {
                console.log('FavoriteItem.js - Received data: ' + {data});
                if (data.result === 'Error removing favorite!') {
                    console.log('Error removing favorite!');
                } else {
                    const localStorageUser = JSON.parse(localStorage.getItem('user'));
                    console.log('FavoriteItem.js - User data (before favorite): ', user);
                    console.log('FavoriteItem.js - New user Favorites (before remove favorite): ', localStorageUser.favorites);
                    localStorageUser.favorites = localStorageUser.favorites.filter(favorite => favorite.productId !== productId)
                    console.log('FavoriteItem.js - New user data (after remove favorite): ', localStorageUser);
                    localStorage.setItem('user', JSON.stringify(localStorageUser));
                    setUser( localStorageUser );
                    console.log('FavoriteItem.js - Favorite removed successfully!');
                }
            })
        }
    };

    return (
        <ListItem>
            <ListItemIcon onClick={() => navigate('/products/' + product.productId)}>
                <img src={`https://api.eletroartica.net/storage/productPics/${product.productPhoto}`} width={50} height={50} />
            </ListItemIcon>
            <Typography gutterBottom variant="body3" component="div" flex={1}>
                <Link href={`/product/${product.productId}`} underline='hover'>
                    {product.productName.length > 30 ? `${product.productName.substring(0, 30)}...` : product.productName}
                </Link>
            </Typography>
            <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteClick(product.productId)}>
                <DeleteIcon />
            </IconButton>
        </ListItem>
    );
}
 
export default FavoriteItem;