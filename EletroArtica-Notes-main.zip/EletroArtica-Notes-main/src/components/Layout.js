import React, { useContext, useState } from 'react';
import Typography from '@mui/material/Typography';
import List from '@mui/material/List';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import MenuIcon from '@mui/icons-material/Menu'
import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import CategoryRoundedIcon from '@mui/icons-material/CategoryRounded';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import { useLocation, useNavigate } from 'react-router-dom';
import ListItemButton from '@mui/material/ListItemButton';
import Toolbar from '@mui/material/Toolbar';
import { StyledDrawer, StyledDivRoot, StyledDivPage, StyledDivToolbar, StyledTypographyTitle, StyledAppBar, StyledIconButton, classes, StyledRightDrawer } from '../styles/Styles';
import { Avatar, IconButton } from '@mui/material';
import useScrollTrigger from '@mui/material/useScrollTrigger';
import Slide from '@mui/material/Slide';
import UserContext from '../contexts/userContext';
import LogoutIcon from '@mui/icons-material/Logout';
import PersonIcon from '@mui/icons-material/Person';

function HideOnScroll(props) {
    const { children, window } = props;
    const trigger = useScrollTrigger({
      target: window ? window() : undefined,
    });
    return (
        <Slide appear={false} direction="down" in={!trigger}>
          {children}
        </Slide>
    );
}

export default function Layout({ children, props }) {
    const navigate = useNavigate();
    const location = useLocation();
    const [openRight, setOpenRight] = useState(false);
    const [openLeft, setOpenLeft] = useState(false);
    const [openFavorites, setOpenFavorites] = useState(false);
    const [openCart, setOpenCart] = useState(false);
    const { user } = useContext(UserContext);

    const toggleDrawerRight = () => {
        setOpenRight(!openRight);
    };

    const toggleDrawerLeft = () => {
        setOpenLeft(!openLeft);
    };

    const leftMenuItems = [
        {
            text: 'Home',
            icon: <HomeRoundedIcon color='primary' />,
            path: '/'
        },
        {
            text: 'Create Note',
            icon: <CategoryRoundedIcon color='primary' />,
            path: '/create'
        },
    ];

    const LoginMenuItems = [];
    if ( user ) {
        LoginMenuItems.push(
            {
                text: 'Profile',
                icon: <PersonIcon color='primary' />,
                path: '/profile'
            },
            {
            text: 'Sign Out',
            icon: <LogoutIcon color='primary' />,
            path: '/logout'
            }
        );
    } else {
        LoginMenuItems.push({
            text: 'Sign In',
            icon: <AccountCircleRoundedIcon color='primary' />,
            path: '/login'
        });
    }

    return (
        <StyledDivRoot>
            {/* App Bar */}
            <HideOnScroll {...props}>
            <StyledAppBar elevation={3} color='transparent'>
                <Toolbar>
                    <StyledIconButton edge="start" color="inherit" aria-label="menu" onClick={toggleDrawerLeft}>
                        <MenuIcon />
                    </StyledIconButton>
                    <Avatar src='/eletroarctic_logo-nobg-small.png' alt='EletroArtica Logo' />
                    <StyledTypographyTitle variant='h5'>
                        EletroArtica - NOTLAR
                    </StyledTypographyTitle>
                    <Typography marginRight={1} variant='h6'>
                        {user ? user.firstName : 'Guest'}
                    </Typography>
                    <IconButton edge="end" color="inherit" aria-label="sidebar" onClick={toggleDrawerRight}>
                        {user ? <Avatar src={`https://api.eletroartica.net/storage/userPics/${user.icon}`} /> : <PersonIcon />}
                    </IconButton>
                </Toolbar>
            </StyledAppBar>
            </HideOnScroll>
            
            {/* Left Side Drawer */}
            <StyledDrawer 
                sx={classes.drawer}
                variant='temporary'
                anchor='left'
                open={openLeft}
                onClose={toggleDrawerLeft}
            >
                <Toolbar>
                    <Avatar src='/eletroarctic_logo-nobg-small.png' alt='EletroArtica Logo' />
                    <StyledTypographyTitle variant='h5'>
                        EletroArtica
                    </StyledTypographyTitle>
                </Toolbar>

                {/* List / links */}
                <List>
                    {leftMenuItems.map(item =>  (
                        <ListItemButton
                            key={item.text}
                            onClick={() => navigate(item.path)}
                            sx={location.pathname === item.path ? classes.active : null}
                        >
                            <ListItemIcon>{item.icon}</ListItemIcon>
                            <ListItemText primary={item.text}/>
                        </ListItemButton>
                    ))}
                </List>
            </StyledDrawer>

            {/* Right Side Drawer */}
            <StyledRightDrawer 
                sx={classes.drawer}
                variant='temporary'
                anchor='right'
                open={openRight}
                onClose={toggleDrawerRight}
            >
                <Toolbar>
                    {user ? <Avatar src={`https://api.eletroartica.net/storage/userPics/${user.icon}`} /> : <Avatar src='/eletroarctic_logo-nobg-small.png' alt='EletroArtica Logo' />}
                    <StyledTypographyTitle variant='h6'>
                        {user ? 'Welcome, ' + user.firstName : 'Welcome, Guest'}
                    </StyledTypographyTitle>
                </Toolbar>

                {/* List / links */}
                <List>
                    {LoginMenuItems.map(item =>  (
                        <ListItemButton
                            key={item.text}
                            onClick={() => {
                                navigate(item.path)
                                toggleDrawerRight()
                            }}
                            sx={location.pathname === item.path ? classes.active : null}
                        >
                            <ListItemIcon>{item.icon}</ListItemIcon>
                            <ListItemText primary={item.text}/>
                        </ListItemButton>
                    ))}
                </List>
            </StyledRightDrawer>

            <StyledDivPage>
                <StyledDivToolbar></StyledDivToolbar>
                { children }
            </StyledDivPage>
        </StyledDivRoot>
    )
}