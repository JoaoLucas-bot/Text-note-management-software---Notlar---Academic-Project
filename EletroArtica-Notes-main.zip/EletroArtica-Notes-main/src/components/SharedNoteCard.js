import React, { useEffect, useState } from 'react';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import { Avatar, Link } from '@mui/material';
import Typography from '@mui/material/Typography';
import { StyledCard } from '../styles/Styles';
import { useNavigate } from 'react-router-dom';

export default function SharedNoteCard({ note }) {
    const [originalUser, setUser] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`https://api.eletroartica.net/api/user/userBasicInfo/${note.userId}`, {
            method: 'GET',
            credentials: 'include',
            withCredentials: true,
        })
        .then(res => res.json())
        .then(user => {
            console.log('User: ', user);
            setUser(user);
        })
    }, []);

    return (
        <div>
            { originalUser && (
                <StyledCard elevation={3} note={note}>
                    <CardHeader
                        avatar={
                            <Avatar src={`https://api.eletroartica.net/storage/userPics/${originalUser.icon}`} />
                        }
                        title={note.noteTitle}
                        subheader={'Shared by: ' + originalUser.firstName + ' ' + originalUser.lastName}
                    />
                    <CardContent>
                    <Typography variant='body2' gutterBottom onClick={() => console.log(navigate('/note/shared/' + note.noteId))}>
                        <Link underline='hover' color="textPrimary" sx={{cursor: "pointer"}}>
                            {note.noteContent}
                        </Link>
                    </Typography>
                    </CardContent>
                </StyledCard>
            )}
        </div>
    )
}