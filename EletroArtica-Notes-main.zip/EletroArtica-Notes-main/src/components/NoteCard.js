import React, { useContext } from 'react';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import { Avatar, Divider, IconButton, Link } from '@mui/material';
import { DeleteOutlined } from '@mui/icons-material'
import Typography from '@mui/material/Typography';
import { StyledCard } from '../styles/Styles';
import UserContext from '../contexts/userContext';
import { useNavigate } from 'react-router-dom';

export default function NoteCard({ note, handleDelete }) {
    const { user } = useContext(UserContext);
    const navigate = useNavigate();

    const readableDate = (noteDate) => {
        const  date = new Date(noteDate);
        return date.toDateString();
    };

    return (
        <div>
        <StyledCard elevation={3} note={note}>
                <CardHeader
                    avatar={
                        <Avatar src={`https://api.eletroartica.net/storage/userPics/${user.icon}`} />
                    }
                    action={
                        <IconButton onClick={() => handleDelete(note.noteId)}>
                            <DeleteOutlined />
                        </IconButton>
                    }
                    title={note.noteTitle}
                    subheader={note.noteCategory}
                />
                <CardContent>
                    <Typography variant='body2' gutterBottom onClick={() => console.log(navigate('/note/' + note.noteId))}>
                        <Link underline='hover' color="textPrimary" sx={{cursor: "pointer"}}>
                            {note.noteContent}
                        </Link>
                    </Typography>
                <Divider />
                <Typography variant='body2' color="textSecondary">
                    Creation Date: {readableDate(note.createDate)}
                </Typography>
                </CardContent>
            </StyledCard>
        </div>
    )
}