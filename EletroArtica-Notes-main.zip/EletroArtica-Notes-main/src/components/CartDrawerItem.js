import { IconButton, ListItem, ListItemIcon, ListItemText, Typography } from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';
import { useContext } from "react";
import UserContext from "../contexts/userContext";
import Link from '@mui/material/Link';


const CartDrawerItem = ({product}) => {
    const navigate = useNavigate();
    console.log('Product in shopping cart: ' + product);
    console.log('Product Name in shopping cart: ' + product.productName);
    const { user, setUser } = useContext(UserContext);

    const handleDeleteClick = (productId) => {
        console.log('Cart item being removed: '+ productId);
        console.log('Current cart items: ' + user.cart)
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        headers.append('Accept', 'application/json');
        console.log('Current user data: ', user);
    
        if (user !== null) {
            fetch('https://api.eletroartica.net/api/shopping/cart/item', {
                method: 'DELETE',
                headers: headers,
                credentials: 'include',
                withCredentials: true,
                body: JSON.stringify({ productId: productId })
            })
            .then(res => {
                console.log('CartDrawerItem.js - Is response 200? ' + {res});
                if (!res.ok) {
                    console.log('Error removing item from shopping cart!');
                } else {
                    fetch('https://api.eletroartica.net/api/shopping/cart', {
                        method: "GET",
                        credentials: 'include',
                        withCredentials: true,
                    })
                    .then((res) => res.json())
                    .then((cartData) => {
                        const localStorageUser = JSON.parse(localStorage.getItem('user'));
                        console.log('CartDrawerItem.js - User data (before cart item removal): ', user);
                        console.log('CartDrawerItem.js - User cart (before item removal): ', localStorageUser.cart);
                        localStorageUser.cart = cartData;
                        console.log('CartDrawerItem.js - New user cart (after item removal): ', localStorageUser);
                        localStorage.setItem('user', JSON.stringify(localStorageUser));
                        setUser( localStorageUser );
                        console.log('CartDrawerItem.js - Cart item removed successfully!');
                    })
                }
            })
/*             .then(data => {
                console.log('CartDrawerItem.js - Received data: ' + {data});
                if (data.result === 'Error removing item from shopping cart') {
                    console.log('Error removing favorite!');
                } else {
                    const localStorageUser = JSON.parse(localStorage.getItem('user'));
                    console.log('FavoriteItem.js - User data (before favorite): ', user);
                    console.log('FavoriteItem.js - New user Favorites (before remove favorite): ', localStorageUser.favorites);
                    localStorageUser.favorites = localStorageUser.favorites.filter(favorite => favorite.productId !== productId)
                    console.log('FavoriteItem.js - New user data (after remove favorite): ', localStorageUser);
                    localStorage.setItem('user', JSON.stringify(localStorageUser));
                    setUser( localStorageUser );
                    console.log('FavoriteItem.js - Favorite removed successfully!');
                }
            }) */
        }
    };

    return (
        <ListItem>
            <ListItemIcon onClick={() => navigate('/products/' + product.productId)}>
                <img src={`https://api.eletroartica.net/storage/productPics/${product.productPhoto}`} width={50} height={50} />
            </ListItemIcon>
            <Typography gutterBottom variant="body3" component="div" flex={1}>
                <Link href={`/product/${product.productId}`} underline='hover'>
                    {product.productName.length > 30 ? `${product.productName.substring(0, 30)}...` : product.productName}
                </Link>
            </Typography>
            <Typography gutterBottom variant="body3" component="div" flex={1}>
                x{product.quantity}
            </Typography>
            <IconButton edge="end" aria-label="delete" onClick={() => handleDeleteClick(product.productId)}>
                <DeleteIcon />
            </IconButton>
        </ListItem>
    );
}
 
export default CartDrawerItem;