// db.js
const sql = require('mssql');
const MssqlStore = require('connect-mssql-v2');

const config = {
    user: 'db_user',
    password: 'db_user_password',
    server: 'db_server_fqdn',
    database: 'db_name',
    options: {
      encrypt: false
    },
    pool: {
      min: 1,
      idleTimeoutMillis: 30000,
    }
};

const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => {
    console.log('Connected to DB');
    return pool;
  }).catch((err) => {
    console.error('Error creating DB connection pool', err);
  });

var sqlOptions = {
  ttl: 3600,
  reapInterval: 3600,
  reapCallback: () => { 
    console.log('expired sessions were removed'); 
  }
};

function createSessionStore(){
  return new MssqlStore(config, sqlOptions);
};

async function cleanUpExpiredSessions(){
  try{
    const pool = await poolPromise;
    const result = await pool.request()
      .query('DELETE FROM Website.dbo.sessions WHERE expires < GETDATE()');
    console.log(`Deleted ${result.rowsAffected} expired sessions`);
  } catch (err) {
    console.error('Error cleaning up expired sessions:', err);
  }
}

module.exports = { poolPromise, createSessionStore, cleanUpExpiredSessions };