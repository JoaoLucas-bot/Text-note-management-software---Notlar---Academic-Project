const passport = require('passport');
const { Strategy } = require('passport-local');
const { getUserByEmail, getUserByID } = require('../database/queries');
const { comparePassword } = require('../helpers/userHelpers');

passport.serializeUser((user, done) => {
    console.log('Serializing user');
    console.log(user);
    done(null, user.userId);
});

passport.deserializeUser(async (userId, done) => {
    console.log('Deserializing user');
    console.log(userId);
    try {
        const user = await getUserByID(userId);
        if (!user) throw new Error('User not found');
        console.log(user);
        done(null, user);
    } catch (err) {
        console.log(err);
        done(err, null);
    }
});

passport.use(
    new Strategy(
        {
            usernameField: 'email',
        },
        async (email, password, done) => {
            console.log('In passport.use')
            console.log(email);
            console.log(password);
            try {
                if(!email || !password) throw new Error('Missing credentials!');
                const userDB = await getUserByEmail(email);
                console.log('userDB password:', userDB.password);
                if (!userDB) throw new Error('User not found!');
                const isValid = await comparePassword(password, userDB.password);
                if (!isValid) {
                    console.log('Invalid authentication');
                    done(null, null);
                }
                else {
                    console.log('User authenticated!', userDB);
                    done(null, userDB);
                }
            } catch (err) {
                console.log(err);
                done(err, null);
            }
        }
    )
);