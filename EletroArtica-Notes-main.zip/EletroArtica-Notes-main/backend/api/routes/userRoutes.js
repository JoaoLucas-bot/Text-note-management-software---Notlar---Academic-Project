const { Router } = require('express');
const passport = require('passport')
const { hashPassword } = require('../helpers/userHelpers');
const { getUserByID, getUserByEmail, insertNewUser, getFavorites, addFavorite, removeFavorite, getCart, updateUserInfo } = require('../database/queries');
const multer = require('multer');

var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'storage/userPics')
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '.jpg') //Appending .jpg
  }
})

var uploads = multer({ storage: storage });

const router = Router();

router.get('/logout', function(req, res, next){
  req.logout(function(err) {
    console.log(req.session)
    console.log(req.cookies)
    if (err) { return next(err); }
    req.session.destroy(() => {
      console.log('session being destroyed');
      res.clearCookie('connect.sid', { path: '/' });
      res.sendStatus(200);
    });
  });
});

router.post('/favorites/', async (req, res) => {
  console.log('Received add favorite request!');
  console.log(req.user);
  if (req.user) {
    result = await addFavorite(req.user.recordset[0].userId.toString(), req.body.favorite.toString());
    if (result.includes('Violation of PRIMARY KEY constraint')) {
      res.status(200).json({'result': 'Favorite already exists!'});
    } else if (result.includes('Error adding favorite')) {
      res.status(500).json({'result': 'Error adding favorite!'});
    } else {res.status(200).json({'result': 'Favorite added successfully!'}); }
  }
});

router.delete('/favorites/', async (req, res) => {
  console.log('Received remove favorite request!');
  console.log(req.user);
  result = await removeFavorite(req.user.recordset[0].userId.toString(), req.body.favorite.toString());
  if (result) {
    res.status(200).json({'result': 'Favorite removed successfully!'});
  } else {
    res.status(500).json({'result': 'Error removing favorite!'});
  }
});

router.get('/userBasicInfo', async (req, res) => {
  if (req.user) {
    console.log(req.user);
    const favorites = await getFavorites(req.user.recordset[0].userId.toString());
    const cart = await getCart(req.user.recordset[0].userId.toString());
    const firstName = req.user.recordset[0].firstName;
    const lastName = req.user.recordset[0].lastName;
    const icon = req.user.recordset[0].userIcon;
    res.status(200).json({'firstName': firstName, 'lastName': lastName, 'icon': icon, 'favorites': favorites, 'cart': cart});
  } else {
    res.status(401).json({'result': 'Not logged in!'});
  }
});

router.get('/userBasicInfo/:id', async (req, res) => {
  const userId = req.params.id;
  if (req.user) {
    console.log(req.user);
    user = await getUserByID(userId);
    const firstName = user.recordset[0].firstName;
    const lastName = user.recordset[0].lastName;
    const icon = user.recordset[0].userIcon;
    res.status(200).json({'firstName': firstName, 'lastName': lastName, 'icon': icon });
  } else {
    res.status(401).json({'result': 'Not logged in!'});
  }
});

router.get('/profile', async (req, res) => {
  if (req.user) {
    console.log(req.user);
    const result = await getUserByID(req.user.recordset[0].userId);
    console.log(result);
    res.status(200).json(result.recordset[0]);
  } else {
    res.status(401).json({'result': 'Not logged in!'});
  }
});

router.put('/profile', uploads.array("userIcon"), async (req, res) => {
  console.log(req.body.firstName);
  console.log(req.files);
  const { firstName, lastName, email } = req.body;
  let { address, nif } = req.body;
  let userIcon;
  const user = await getUserByEmail(email);

  if (req.body.userIcon) {
    userIcon = user.userIcon;
  } else {
    userIcon = req.files[0].path.split('/')[2];
  }

  if (nif === '' || nif === "null") nif = null;
  if (address === '' || address === "null") address = null;
  console.log(nif);
  const result = await updateUserInfo(user.userId, firstName, lastName, address, nif, userIcon);
  console.log(result);
  if (result === 'Updated user info successfully!') {
    res.status(200).json({'result': 'Profile updated successfully!'});
  } else {
    res.status(500).json({'result': 'Error updating profile!'});
  }
});

router.use((req, res, next) => {
  console.log('Inside /auth Authentication Check Middleware');
  console.log(req.user);
  if (!req.user) next();
  else {
    console.log('Already logged in!');
    res.status(401).send('Already logged in!');
  }
});

router.post('/registration', async (req, res) => {
  if (req.session.user) {
    console.log('Already logged in!', req.session.user.email);
    res.status(401).json({'result': 'Already logged in!'});
    return;
  }

  const { email, password, firstName, lastName} = req.body;

  const userExistsResult = await getUserByEmail(email);

  if ( userExistsResult ) {
    console.log('Email already in use!');
    res.json({'result': 'Email already in use!'});
    return;
  }

  const hashedPassword = hashPassword(password); 
  if(await insertNewUser(email, hashedPassword, firstName, lastName)) {
    res.status(201).json({result: 'User created sucessfully!'});
  } else res.status(500).json({result: 'Error creating user!'});
});

router.post('/login', passport.authenticate('local'), async (req, res) => {
  console.log('Successful login!');
  res.sendStatus(200);
});

module.exports = router;
