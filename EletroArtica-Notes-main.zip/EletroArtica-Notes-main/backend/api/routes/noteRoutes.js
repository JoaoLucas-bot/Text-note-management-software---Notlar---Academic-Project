const { Router } = require('express');
const { getSharedNote ,shareNoteByEmail, getNotes, getNote, createNote, updateNote, deleteNote, getSharedNotes, getUserByEmail, getNoteById } = require('../database/queries');
const { encryptNoteContent, decryptNoteContent } = require('../helpers/noteHelpers');

const router = Router();

router.use((req, res, next) => {
    console.log('In notes auth check')
    if (req.user) next();
    else {
        console.log('Not authenticated')
        res.sendStatus(401);
    }
});

router.get('/', async (req, res) => {
    console.log('Received notes request!')
    const userId = req.user.recordset[0].userId;
    try {
        const notes = await getNotes(userId);
        console.log('Notes retrieved successfully! ' + notes);
        const decryptedNotes = await decryptNoteContent(notes);
        console.log('Notes retrieved successfully! ' + decryptedNotes);
        res.status(200).json(decryptedNotes);
    } catch (err) {
        console.log('Error with getNotes query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.get('/note/:id', async (req, res) => {
    console.log('Received note request!')
    const userId = req.user.recordset[0].userId;
    const noteId = req.params.id;
    try {
        const notes = await getNote(userId, noteId);
        console.log('Note retrieved successfully! ' + notes);
        const decryptedNotes = await decryptNoteContent(notes);
        console.log('Notes retrieved successfully! ' + decryptedNotes);
        res.status(200).json(decryptedNotes);
    } catch (err) {
        console.log('Error with getNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.post('/create', async (req, res) => {
    console.log('Received create note request!')
    const { title, content, category } = req.body;
    const userId = req.user.recordset[0].userId;
    console.log(req.user.recordset[0].userId)
    console.log('userId: ' + userId + ' title: ' + title + ' content: ' + content + ' category: ' + category)
    try {
        const encryptedContent = await encryptNoteContent(content);
        console.log('Encrypted content: ' + encryptedContent);
        const note = await createNote(userId, title, category, encryptedContent.toString());
        console.log('Note created successfully! ' + note);
        res.sendStatus(200);
    } catch (err) {
        console.log('Error with createNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.put('/note/:id', async (req, res) => {
    console.log('Received update note request!')
    const noteId = req.params.id;
    const userId = req.user.recordset[0].userId;
    const { title, category, content } = req.body;
    try {
        const userNotes = await getNotes(userId);
        console.log('User notes: ' + userNotes);
        if (userNotes.find(note => note.noteId == noteId)) {
            const encryptedContent = await encryptNoteContent(content);
            const note = await updateNote(noteId, title, category, encryptedContent);
            console.log('Note updated successfully! ' + note);
            res.status(200).json({'result': 'Note updated successfully!'}); 
        } else {
            res.status(401).send({'result': 'Note updated successfully'});
        }
    } catch (err) {
        console.log('Error with updateNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.delete('/note/:id', async (req, res) => {
    console.log('Received delete note request!')
    const noteId = req.params.id;
    const userId = req.user.recordset[0].userId;
    try {
        const note = await deleteNote(userId, noteId);
        if (note == 0) {
            res.status(401).send({'result': 'Note not found or not authorized to delete'});
            console.log('Note not found or not authorized to delete ' + note);
        }
        else {
            res.status(200).send({'result': 'Note deleted successfully!'});
            console.log('Note deleted successfully! ' + note);
        }
    } catch (err) {
        console.log('Error with deleteNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.get('/shared', async (req, res) => {
    console.log('Received shared notes request!')
    const userId = req.user.recordset[0].userId;
    try {
        const notes = await getSharedNotes(userId);
        console.log('Notes retrieved successfully! ' + notes);
        const decryptedNotes = await decryptNoteContent(notes);
        res.status(200).json(decryptedNotes);
    } catch (err) {
        console.log('Error with getNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.get('/shared/:id', async (req, res) => {
    console.log('Received shared note request!')
    const userId = req.user.recordset[0].userId;
    const noteId = req.params.id;
    try {
        const permittedNoteId = await getSharedNote(userId, noteId);
        console.log('Shared Note registry retrieved successfully! ' + permittedNoteId[0].noteId);
        const note = await getNoteById(permittedNoteId[0].noteId);
        console.log('Note retrieved successfully! ' + note);
        const decryptedNotes = await decryptNoteContent(note);
        console.log('Notes retrieved successfully! ' + decryptedNotes);
        res.status(200).json(decryptedNotes);
    } catch (err) {
        console.log('Error with getNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.put('/shared/:id', async (req, res) => {
    console.log('Received update note request!')
    const noteId = req.params.id;
    const userId = req.user.recordset[0].userId;
    const { title, category, content } = req.body;
    try {
        const sharedNotes = await getSharedNotes(userId);
        if (sharedNotes.find(note => note.noteId == noteId)) {
            const encryptedContent = await encryptNoteContent(content);
            const note = await updateNote(noteId, title, category, encryptedContent);
            console.log('Note updated successfully! ' + note);
            res.status(200).json({'result': 'Note updated successfully'});
        } else {
            res.status(401).send({'result': 'Note not found or not authorized to update'});
        }
    } catch (err) {
        console.log('Error with updateNote query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.post('/share/:id', async (req, res) => {
    console.log('Received share note request!')
    const noteId = req.params.id;
    const userId = req.user.recordset[0].userId;
    const { email } = req.body;
    try {
        const userToShareWith = await getUserByEmail(email);
        console.log('User to share with: ' + userToShareWith.userId);
        const userNotes = await getNotes(userId);
        if (userNotes.find(note => note.noteId == noteId)) {
            const note = await shareNoteByEmail(noteId, userToShareWith.userId);
            console.log('Note shared successfully! ' + note);
            res.status(200).json({'result': 'Note shared successfully'});
        } else {
            res.status(401).json({'result': 'Note not found or not authorized to share'});
        }
    } catch (err) {
        console.log('Error with shareNoteByEmail query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

module.exports = router;