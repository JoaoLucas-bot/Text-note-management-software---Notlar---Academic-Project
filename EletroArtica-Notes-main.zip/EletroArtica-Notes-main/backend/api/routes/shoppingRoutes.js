const { add } = require('date-fns');
const { getCart, removeCartItem, addCartItem, modifyCartItem, addOrder, addOrderLine } = require('../database/queries');
const { Router } = require('express');
const { sendEmail, html } = require('../helpers/shoppingHelpers');



const router = Router();

router.use((req, res, next) => {
    console.log('In shopping auth check')
    if (req.user) next();
    else {
        console.log('Not authenticated')
        res.sendStatus(401);
    }
});

router.get('/cart', async (req, res) => {
    const cart = await getCart(req.user.recordset[0].userId.toString());
    if (!cart) {
        res.send('You have no cart session')
    } else {
        console.log('Cart items: ', cart);
        res.send(cart);
    }
});

router.post('/cart/item', async (req, res) => {
    const currentItems = await getCart(req.user.recordset[0].userId.toString());
    console.log('Current items: ', currentItems);
    const itemExists = currentItems.filter(item => item.productId === req.body.productId );
    console.log('Item exists: ', itemExists)
    if (itemExists.length === 0) {
        const cart = await addCartItem(req.user.recordset[0].userId.toString(), req.body.productId.toString(), req.body.quantity.toString());
        if (cart.includes('Error adding item to shopping cart')) {
            res.sendStatus(500).json({'result': 'Error adding item to shopping cart'})
        } else {
            console.log('Added item to shopping cart successfully!');
            res.json({'result': 'Added item to shopping cart successfully!'});
        }
    } else {
        console.log('Sum: ' + req.body.quantity + ' + ' + itemExists[0].quantity)
        const cart = await modifyCartItem(req.user.recordset[0].userId.toString(), req.body.productId.toString(), (req.body.quantity + itemExists[0].quantity).toString());
        if (cart.includes('Error updating shopping cart item')) {
            res.sendStatus(500).json({'result': 'Error updating shopping cart item'})
        } else {
            console.log('Updated shopping cart item successfully!');
            res.json({'result': 'Updated shopping cart item successfully!!'});
        }
    }
});

router.delete('/cart/item', async (req, res) => {
    const cart = await removeCartItem(req.user.recordset[0].userId.toString(), req.body.productId.toString());
    if (cart.includes('Error removing item to shopping cart')) {
        res.sendStatus(500).json({'result': 'Error removing item from shopping cart'})
    } else {
        console.log('Removed item to shopping cart successfully!');
        res.json({'result': 'Removed item to shopping cart successfully!'});
    }
});

router.post('/checkout', async (req, res) => {
    console.log('Checkout form: ', req.body.checkoutForm);
    const { firstName, lastName, address1, zip, country } = req.body.checkoutForm;
    const { cart, cardType, total } = req.body;
    const cardNumber = req.body.checkoutForm.cardNumber.slice(req.body.checkoutForm.cardNumber.length - 4);
    console.log('Adding order');
    const orderId = await addOrder(req.user.recordset[0].userId.toString(), firstName, lastName, address1, zip, country, cardNumber, cardType, total);
    if (orderId === 'Error adding order') {
        res.sendStatus(500).json({'result': 'Error adding order'})
        return;
    } else {
        console.log('Added order successfully!');
        console.log('Adding order items');
        console.log('cart: ', cart);
        const orderLines = await addOrderLine(orderId, cart);
        if (orderLines === 'Error adding order lines' ) {
            res.sendStatus(500).json({'result': 'Error adding order lines'})
            return;
        } else {        
            console.log('Added order lines successfully!');
            await sendEmail(html(orderId, cart), req.user.recordset[0].email);
            res.json({'orderId': orderId});
        }
    }
});

module.exports = router;