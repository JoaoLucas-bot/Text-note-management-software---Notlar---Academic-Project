const { Router } = require('express');
const { getProducts, getFavoriteProducts, getBestSellingProducts } = require('../database/queries');

const router = Router();

/* router.use((req, res, next) => {
    console.log('Inside product Auth Check Middleware');
    console.log(req.user);
    if (req.user) next();
    else {
        res.sendStatus(401);
    }
}); */

router.get('/', async (req, res) => {
    console.log('Received product request!')
    try {
        if (req.query.productList !== undefined) {
            const jsonParsed = JSON.parse(req.query.productList);
            const jsonArrayString = "[" + jsonParsed.split(',').map(value => `"${value}"`).join(',') + "]";
            console.log(jsonArrayString);
            const productList = await getProducts(jsonArrayString);
            res.status(200).json(productList);
        } else {
            const allProductList = await getProducts(null);
            res.status(200).json(allProductList);
        }
    } catch (err) {
        console.log('Error with getProducts query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});}
});

router.get('/favorites', async (req, res) => {
    console.log('Received favorites request!')
    try {
        const favorites = await getFavoriteProducts();
        res.status(200).json({'favorites': favorites});
    } catch (err) {
        console.log('Error with getFavorites query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

router.get('/bestSellers', async (req, res) => {
    console.log('Received bestSellers request!')
    try {
        const bestSellers = await getBestSellingProducts();
        res.status(200).json({'bestSellers': bestSellers});
    } catch (err) {
        console.log('Error with getBestSellingProducts query.', err);
        res.status(500).send({'result': 'Error fetching data from the database'});
    }
});

module.exports = router;

