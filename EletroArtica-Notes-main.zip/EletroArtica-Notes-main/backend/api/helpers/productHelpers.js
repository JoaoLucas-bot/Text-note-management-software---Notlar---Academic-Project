const express = require('express');
const multer = require('multer');
const app = express();

//Set up Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, '../../storage/productPics/'); // Specify the destination folder for uploaded files
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname); // Set a unique filename
    },
});
