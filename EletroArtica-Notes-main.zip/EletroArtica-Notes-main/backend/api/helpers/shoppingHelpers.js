const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'outlook',
    auth: {
        user: 'username',
        pass: 'password'
    }
});

function html(orderId, order) {
    return `
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
        <h2>Thank you for your order!</h2>
        <p>Your order number is #${orderId}. We will send you an update when your order has shipped.</p>
        <h3>Order details:</h3>
        <ul>
            ${order.map(item => {
                return `
                <li>
                    <h4>${item.productName}</h4>
                    <p>Quantity: ${item.quantity}</p>
                    <p>Unit Price: €${item.productPrice}</p>
                </li>
                `
            })}
        </ul>
        <h3>Total: €${order.reduce((acc, curr) => acc + (curr.productPrice * curr.quantity), 0)}</h3>
    </div>
    `
}

async function sendEmail(message, email) {
    const mailOptions = {
        from: 'EletroArtica <30008241@students.ual.pt>',
        to: email,
        subject: 'Your order has been placed!',
        html: message
    };
    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.log(err);
        } else {
            console.log('Email sent: ', info.response);
        }
    });
}

module.exports = { sendEmail, html }   