const crypto = require('crypto');


const encryptNoteContent = async (noteContent) => {
    // Generate a key and an initialization vector (IV)
    const algorithm = 'aes-256-cbc';
    const key = Buffer.from('6ec767768cbd5b50bbf648bc6faf9c2b9746ffb86da1cad651277c3366caaf1d', 'hex');
    const iv = Buffer.from('5229881628725990a5354fb212ea997a', 'hex');

    // Create a cipher
    const cipher = crypto.createCipheriv(algorithm, key, iv);

    // Encrypt the text
    return Buffer.concat([cipher.update(noteContent, 'utf-8'), cipher.final()]).toString('hex');  
};

const decryptNoteContent = async (notes) => {
    // Generate a key and an initialization vector (IV)
    const algorithm = 'aes-256-cbc';
    const key = Buffer.from('6ec767768cbd5b50bbf648bc6faf9c2b9746ffb86da1cad651277c3366caaf1d', 'hex');
    const iv = Buffer.from('5229881628725990a5354fb212ea997a', 'hex');
    console.log('In decryptNoteContent');
    console.log(notes);
    // Create a decipher
    const decryptedNotes = [];
    
    notes.map((note) => {
        console.log('Note before decrypt: ' + note.noteContent);
        const encryptedNoteContent = note.noteContent;
        const decipher = crypto.createDecipheriv(algorithm, key, iv);
        // Decrypt the text
        note.noteContent = decipher.update(encryptedNoteContent, 'hex');
        note.noteContent = Buffer.concat([note.noteContent, decipher.final()]).toString();
        decryptedNotes.push(note);
        console.log('Notes after decrypt: ' + decryptedNotes[0].noteContent);
    })

    return decryptedNotes;
};

module.exports = { encryptNoteContent, decryptNoteContent };