const bcrypt = require('bcryptjs');

// Hash a password. Will be used to hash password before
// they are stored in the database
function hashPassword(password) {
    const salt = bcrypt.genSaltSync();
    return bcrypt.hashSync(password, salt);
};

// Compare a password with its hash
function comparePassword(raw, hash) {
    return bcrypt.compareSync(raw, hash);
};

module.exports = { hashPassword, comparePassword };