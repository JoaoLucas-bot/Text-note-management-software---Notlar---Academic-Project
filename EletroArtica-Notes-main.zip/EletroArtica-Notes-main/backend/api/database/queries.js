const sql = require('mssql');
const { poolPromise } = require('../../db');

async function getUserByEmail(email) {
    console.log('In getUserByEmail query');
    const sqlQuery = 'SELECT * FROM Website.dbo.Users WHERE email = @email';
    try {
        const pool = await poolPromise;
        console.log('Getting user by email:', email);
        const result = await pool.request()
            .input('email',sql.NVarChar, email)
            .query(sqlQuery);
        return result.recordset[0];
    } catch {
        console.log('Error with SQL query getUserByEmail.', err);
        return;
    }
};

async function getUserByID(id) {
    console.log('In getUserByID query');
    const sqlQuery = 'SELECT * FROM Website.dbo.Users WHERE userId = @userId';
    try {
        const pool = await poolPromise;
        console.log('Getting user by ID:', id);
        return await pool.request()
            .input('userId',sql.Int, id)
            .query(sqlQuery);
    } catch {
        console.log('Error with sql query getUserByID.', err);
        return;
    }
};

async function insertNewUser(email, hashedPassword, firstName, lastName){
    console.log('In insertNewUser query');
    try {
        const pool = await poolPromise;
        const sqlInsert = 'INSERT INTO Website.dbo.Users (email, password, firstName, lastName) VALUES (@email, @password, @firstName, @lastName)';
        pool.request()
          .input('email', sql.NVarChar, email)
          .input('password', sql.NVarChar, hashedPassword)
          .input('firstName', sql.NVarChar, firstName)
          .input('lastName', sql.NVarChar, lastName)
          .query(sqlInsert)
        return true
    } catch {
        console.log('Error creating user!', err);
        return false;
    }
};

async function getProducts(productList){
    console.log('In getProducts query');
    try {
        const pool = await poolPromise;
        if (productList) {
            const sqlQuery = 'SELECT * FROM Website.dbo.Products WHERE productId IN (SELECT value FROM OPENJSON(@productList))';
            result = await pool.request()
                .input('productList', sql.NVarChar, productList)
                .query(sqlQuery);
            return result.recordset;
        }
        const sqlQuery = 'SELECT * FROM Website.dbo.Products';
        result = await pool.query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting products:', err);
        return;
    }
}

async function getFavoriteProducts(){
    console.log('In getFavoriteProducts query');
    try {
        const pool = await poolPromise;
        const sqlQuery = `
        WITH FavoritedProducts AS (
            SELECT
              p.*,
              COUNT(f.userId) AS favoritesCount
            FROM
              products p
              LEFT JOIN FavoriteProducts f ON p.productId = f.productId
            GROUP BY
              p.productId, p.productName, p.categoryId, p.productDescription, p.productPhoto, p.productPrice, p.productStock, p.providerId -- Include other product details
          )
          SELECT
          TOP 4
            productId,
            productName,
            categoryId,
            productDescription,
            productPhoto,
            productPrice,
            productStock,
            providerId
          FROM
            FavoritedProducts
          ORDER BY
            favoritesCount DESC
          `;
        const result = await pool.request()
            .query(sqlQuery);
        console.log(result.recordset);
        return result.recordset;
    } catch (err) {
        console.log('Error getting favorite products:', err);
        return;
    }
};

async function getBestSellingProducts(){
    console.log('In getBestSellingProducts query');
    try {
        const pool = await poolPromise;
        const sqlQuery = `
        WITH RankedProducts AS (
            SELECT
              p.*,
              ROW_NUMBER() OVER (ORDER BY SUM(o.quantity) DESC) AS rank
            FROM
              dbo.OrderLine o
              JOIN Products p ON o.productId = p.productId
            GROUP BY
              p.productId, p.productName, p.categoryId, p.productDescription, p.productPhoto, p.productPrice, p.productStock, p.providerId
          )
          SELECT
            productId,
            productName,
            categoryId,
            productDescription,
            productPhoto,
            productPrice,
            productStock,
            providerId
          FROM
            RankedProducts
          WHERE
            rank <= 4;
          `;
        const result = await pool.request()
            .query(sqlQuery);
        console.log(result.recordset);
        return result.recordset;
    } catch (err) {
        console.log('Error getting best selling products:', err);
        return;
    }
};

async function getFavorites(userId){
    console.log('In getFavorites query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT productId, productName, productPhoto FROM Website.dbo.Products WHERE productId IN (SELECT ProductId FROM [dbo].FavoriteProducts WHERE userId = @userId )';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .query(sqlQuery);
        console.log(result.recordset);
        return result.recordset;
    } catch (err) {
        console.log('Error getting products:', err);
        return;
    }
}

async function addFavorite(userId, favoriteId){
    console.log('In addFavorite insert');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'INSERT INTO [dbo].FavoriteProducts (userId, productId) VALUES (@userId, @productId)';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('productId', sql.NVarChar, favoriteId)
            .query(sqlQuery);
        console.log('Added favorite successfully!');
        return result.recordset.toString();
    } catch (err) {
        console.log('Error adding favorite:', err);
        return err.toString();
    }
}

async function removeFavorite(userId, favoriteId){
    console.log('In removeFavorite query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'DELETE FROM [dbo].FavoriteProducts WHERE userId = @userId AND productId = @productId';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('productId', sql.NVarChar, favoriteId)
            .query(sqlQuery);
        console.log('Removed favorite successfully!');
        return 'Removed favorite successfully!';
    } catch (err) {
        console.log('Error removing favorite:', err);
    }
}

async function getCart(userId){
    console.log('In getcart query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT p.productId, p.productName, p.productPhoto, p.productPrice, sc.quantity FROM products p JOIN shoppingCart sc ON p.productId = sc.productId WHERE sc.userId = @userId;';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .query(sqlQuery);
        console.log(result.recordset);
        return result.recordset;
    } catch (err) {
        console.log('Error getting shopping cart items:', err);
        return;
    }
}

async function addCartItem(userId, itemId, quantity){
    console.log('In addCartItem insert');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'INSERT INTO [dbo].ShoppingCart (userId, productId, quantity) VALUES (@userId, @itemId, @quantity)';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('itemId', sql.NVarChar, itemId)
            .input('quantity', sql.NVarChar, quantity)
            .query(sqlQuery);
        console.log('Added item to shopping cart successfully!');
        return 'Added item to shopping cart successfully!';
    } catch (err) {
        console.log('Error adding item to shopping cart:', err);
        return 'Error adding item to shopping cart';
    }
}

async function removeCartItem(userId, itemId) {
    console.log('In removeCartItem query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'DELETE FROM [dbo].ShoppingCart WHERE userId = @userId AND productId = @itemId';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('itemId', sql.NVarChar, itemId)
            .query(sqlQuery);
        console.log('Removed item from shopping cart successfully!');
        return 'Removed item from shopping cart successfully!';
    } catch (err) {
        console.log('Error removing item from shopping cart:', err);
        return err.toString();
    }
}

async function modifyCartItem(userId, itemId, quantity){
    console.log('In modifyCartItem insert');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'UPDATE [dbo].ShoppingCart SET quantity = @quantity WHERE userId = @userId AND productId = @itemId';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('itemId', sql.NVarChar, itemId)
            .input('quantity', sql.NVarChar, quantity)
            .query(sqlQuery);
        console.log('Modified item quantity in shopping cart successfully!');
        return 'Modified item quantity in shopping cart successfully!';
    } catch (err) {
        console.log('Error modifying item quantity in shopping cart:', err);
        return 'Error modifying item quantity in shopping cart';
    }
}

async function addOrder(userId, firstName, lastName, address1, zip, country, cardNumber, cardType, total){
    console.log('In addOrder insert');
    console.log('userId: ', userId);
    console.log('firstName: ', firstName);
    console.log('lastName: ', lastName);
    console.log('address1: ', address1);
    console.log('zip: ', zip);
    console.log('country: ', country);
    console.log('cardNumber: ', cardNumber);
    console.log('cardType: ', cardType);
    console.log('total: ', total);
    try {
        const pool = await poolPromise;
        const sqlQuery = 'INSERT INTO [dbo].Orders (userId, firstName, lastName, address1, zip, country, cardNumber, cardType, orderDate, total) VALUES (@userId, @firstName, @lastName, @address1, @zip, @country, @cardNumber, @cardType, @orderDate, @total); SELECT SCOPE_IDENTITY() AS orderId';
        const result = await pool.request()
            .input('userId', sql.NVarChar, userId)
            .input('firstName', sql.NVarChar, firstName)
            .input('lastName', sql.NVarChar, lastName)
            .input('address1', sql.NVarChar, address1)
            .input('zip', sql.NVarChar, zip)
            .input('country', sql.NVarChar, country)
            .input('cardNumber', sql.NVarChar, cardNumber)
            .input('cardType', sql.NVarChar, cardType)
            .input('orderDate', sql.DateTime, new Date())
            .input('total', sql.Money, total)
            .query(sqlQuery);
        console.log('result: ', result);
        const orderId = result.recordset[0].orderId;
        console.log('orderId: ', orderId);
        console.log('New order registered!');
        return orderId;
    } catch (err) {
        console.log('Error adding order: ', err);
        return 'Error adding order';
    }
}

async function addOrderLine( orderId, cartContent ){
    console.log('In addOrderLine insert');
    try {
        const pool = await poolPromise;
        let sqlQuery = 'INSERT INTO [dbo].OrderLine (orderId, productId, quantity) VALUES ';
        const values = [];
        cartContent.forEach((item, index) => {
            console.log('item: ', item);
            sqlQuery += `(${orderId}, ${item.productId}, ${item.quantity}), `;
        });

        console.log('sqlQuery: ', sqlQuery);
        sqlQuery = sqlQuery.slice(0, -2);
        console.log('sqlQuery: ', sqlQuery);
        console.log('values: ', values);
        const result = await pool.request()
            .query(sqlQuery);
        console.log('New order lines registered!');
        return 'New order lines registered';
    } catch (err) {
        console.log('Error adding order lines: ', err);
        return 'Error adding order lines';
    }
}

async function updateUserInfo(userId, firstName, lastName, address, nif, userIcon){
    console.log('In updateUserInfo query');
    console.log('userId: ', userId);
    try {
        const pool = await poolPromise;
        const sqlQuery = 'UPDATE Website.dbo.Users SET firstName = @firstName, lastName = @lastName, address = @address, nif = @nif, userIcon = @userIcon WHERE userId = @userId';
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .input('firstName', sql.NVarChar, firstName)
            .input('lastName', sql.NVarChar, lastName)
            .input('address', sql.NVarChar, address)
            .input('nif', sql.Int, nif)

        if(userIcon !== ''){
            result.input('userIcon', sql.NVarChar, userIcon)
        }
        result.query(sqlQuery);
        console.log('Updated user info successfully!');
        return 'Updated user info successfully!';
    } catch (err) {
        console.log('Error updating user info:', err);
        return 'Error updating user info';
    }
}



/*************************************** NOTLAR Queries *******************************************/

async function getNotes(userId) {
    console.log('In getNotes query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT * FROM Notes WHERE userId = @userId';
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting notes:', err);
        return;
    }
}

async function getNote(userId, noteId) {
    console.log('In getNote query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT * FROM Notes WHERE userId = @userId AND noteId = @noteId';
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .input('noteId', sql.Int, noteId)
            .query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting notes:', err);
        return;
    }
}

async function getNoteById(noteId) {
    console.log('In getNoteById query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT * FROM Notes WHERE noteId = @noteId';
        const result = await pool.request()
            .input('noteId', sql.Int, noteId)
            .query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting notes:', err);
        return;
    }
}

async function getSharedNotes(userId) {
    console.log('In getSharedNotes query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT n.noteId, n.noteTitle, n.noteCategory, n.createDate, n.noteContent, n.userId, sn.sharePermission FROM Notes n JOIN SharedNotes sn ON n.noteId = sn.noteId WHERE sn.userId = @userId'
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting notes:', err);
        return;
    }
}

async function getSharedNote(userId, noteId) {
    console.log('In getSharedNotes query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'SELECT n.noteId, n.noteTitle, n.noteCategory, n.createDate, n.noteContent, n.userId, sn.sharePermission FROM Notes n JOIN SharedNotes sn ON n.noteId = sn.noteId WHERE sn.userId = @userId AND sn.noteId = @noteId'
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .input('noteId', sql.Int, noteId)
            .query(sqlQuery);
        return result.recordset;
    } catch (err) {
        console.log('Error getting notes:', err);
        return;
    }
}

async function createNote(userId, noteTitle, noteCategory, noteContent) {
    console.log('In createNote query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'INSERT INTO Notes (userId, noteTitle, noteCategory, createDate, noteContent) VALUES (@userId, @noteTitle, @noteCategory, @createDate, @noteContent)';
        const result = await pool.request()
            .input('userId', sql.Int, userId)
            .input('noteTitle', sql.NVarChar, noteTitle)
            .input('noteCategory', sql.NVarChar, noteCategory)
            .input('createDate', sql.DateTime, new Date())
            .input('noteContent', sql.NVarChar, noteContent)
            .query(sqlQuery);
        console.log('New note registered!');
        return 'New note registered!';
    } catch (err) {
        console.log('Error creating note:', err);
        return 'Error creating note';
    }
}

const deleteNote = async (userID, noteId) => {
    console.log('In deleteNote query');
    try {
        const pool = await poolPromise;
        console.log('Deleting share registry')
        const sqlQuery2 = 'DELETE FROM SharedNotes WHERE noteId = @noteId';
        const result2 = await pool.request()
            .input('noteId', sql.Int, noteId)
            .query(sqlQuery2);
        console.log('Deleted shares: ' + result2.rowsAffected);
        const sqlQuery = 'DELETE FROM Notes WHERE noteId = @noteId AND userId = @userId';
        const result = await pool.request()
            .input('userId', sql.Int, userID)
            .input('noteId', sql.Int, noteId)
            .query(sqlQuery);
        console.log('Note deleted!');
        return result.rowsAffected;
    } catch (err) {
        console.log('Error deleting note:', err);
        return 'Error deleting note';
    }
};

async function updateNote(noteId, noteTitle, noteCategory, noteContent) {
    console.log('In updateNote query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'UPDATE Notes SET noteTitle = @noteTitle, noteCategory = @noteCategory, noteContent = @noteContent WHERE noteId = @noteId';
        const result = await pool.request()
            .input('noteId', sql.Int, noteId)
            .input('noteTitle', sql.NVarChar, noteTitle)
            .input('noteCategory', sql.NVarChar, noteCategory)
            .input('noteContent', sql.NVarChar, noteContent)
            .query(sqlQuery);
        console.log('Note updated!');
        return result.rowsAffected;
    } catch (err) {
        console.log('Error updating note:', err);
        return 'Error updating note';
    }
}

async function shareNoteByEmail(noteId, userId) {
    console.log('In shareNoteByEmail query');
    try {
        const pool = await poolPromise;
        const sqlQuery = 'INSERT INTO SharedNotes (noteId, userId, sharePermission) VALUES (@noteId, @userId, @sharePermission)';
        const result = await pool.request()
            .input('noteId', sql.Int, noteId)
            .input('userId', sql.Int, userId)
            .input('sharePermission', sql.NVarChar, 'write')
            .query(sqlQuery);
        console.log('Note shared!');
        return result.rowsAffected;
    } catch (err) {
        console.log('Error sharing note:', err);
        return 'Error sharing note';
    }
}

module.exports = { getNoteById, getSharedNote, shareNoteByEmail, getNote, updateNote, getSharedNotes, getUserByEmail, getUserByID, insertNewUser, getProducts, getFavorites, addFavorite, removeFavorite, removeCartItem, addCartItem, getCart, modifyCartItem, addOrder, addOrderLine, updateUserInfo, getFavoriteProducts, getBestSellingProducts, createNote, deleteNote, getNotes };