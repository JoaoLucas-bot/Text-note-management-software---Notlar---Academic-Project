// app.js (main app file)
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const { createSessionStore, cleanUpExpiredSessions } = require('./db');
const passport = require('passport');
require('./api/strategies/locals');
const https = require('https');
const fs = require('fs');
const path = require('path');
const productRoutes = require('./api/routes/productRoutes');
const userRoutes = require('./api/routes/userRoutes');
const shoppingRoutes = require('./api/routes/shoppingRoutes');
const noteRoutes = require('./api/routes/noteRoutes');
const app = express();

// Allowed origins to connect to the API
const allowedOrigins = [
  'https://api.eletroartica.net:3000',
  'http://127.0.0.1:5500',
  'https://eletroartica.net',
  'https://www.eletroartica.net',
  'https://notlar.eletroartica.net',
  'http://localhost:3001'
];

// Enable CORS for all routes
app.use(cors({ 
  origin: allowedOrigins,
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true, // Enable credentials (cookies, authorization headers, etc.)
}));

app.use(express.json());
app.use(express.urlencoded());

app.use(
  session({
      secret: 'AKNFONFOENFON',
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: true,
        httpOnly: true,
        sameSite: 'none',
        maxAge: 60 * 60 * 24 * 1000
      },
      store: createSessionStore(),
  })
);

const interval = setInterval(cleanUpExpiredSessions, 60 * 1000);

app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) => {
  console.log(`${req.method} - ${req.url}`);
  next();
});

//Routes
app.use('/api/products', productRoutes);
app.use('/api/user', userRoutes);
app.use('/api/shopping', shoppingRoutes);
app.use('/storage', express.static(__dirname + '/storage'));
app.use('/api/notes', noteRoutes);

// Configure HTTPS server
const httpsOptions = {
    key: fs.readFileSync(path.join(__dirname, '../certs/api_cert.key')),
    cert: fs.readFileSync(path.join(__dirname, '../certs/api_cert.crt')),
};

// Create HTTPS server
const port = 3000;
https.createServer(httpsOptions, app).listen(port, () => {
    console.log(`Server listening on port ${port}`);
});

  
