# EletroArtica-Notes
Projeto final da cadeira SDP 23/24

Neste projeto será desenvolvida uma webapp, em REACT, para criação, edição e partilha de notas online.
O backend será desenvolvido em NodeJS (API), a correr em Debian 12, e storage/SQL Server 2019 a correr em Windows Server 2022.

## Tasks completas
- (Infrastructure) Servidor Debian 12 com NodeJS
- (Infrastructure) Servidor Windows Server 2022 com SQL Server 2019
- (API) Rotas de autenticação do utilizador na webapp com sessions
- (Frontend) Desenvolvimento da Webapp frontend
- (Frontend) Deployment da webapp para servidores Web
- (Frontend) Configuração de Load Balancer da webapp
- (API) Desenvolver rotas de criação, edição e remoção de notas
- (API) Desenvolver queries para criação, edição e remoção de notas
- (Infrastructure) Levantar servidor Debian 12 com NodeJS para frontend
- (Infrastructure) Levantar segundo servidor Debian 12 com NodeJS para redundancia
- (Infrastructure) Configuração de load balancer para os servidores API
- (Infrastructure) Levantar segundo servidor Windows Server 2022 com SQL Server 2019 para redundancia
- (Infrastructure) Configuração de cluster SQL Server com os Windows Server 2022
